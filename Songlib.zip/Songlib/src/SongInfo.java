public class SongInfo {

    public String name;
    public String artist;
    public String album;
    public String year;

        public SongInfo (String n, String ar, String al, String y) {
            name = n;
            artist = ar;
            album = al;
            year = y;
        }

    }


